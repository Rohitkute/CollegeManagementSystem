package com.Cms.Login.custom_exceptions;

@SuppressWarnings("serial")
public class ResourceNotFoundException {
	public ResourceNotFoundException(String mesg) {
		super(mesg);
	}

}
