package com.Cms.Login.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Cms.Login.entities.Professor;
import com.Cms.Login.entities.Subject;

public interface SubjectRepository extends JpaRepository<Subject, Long> {
	List<Subject> findAllByProfessor(Professor prof);

}
