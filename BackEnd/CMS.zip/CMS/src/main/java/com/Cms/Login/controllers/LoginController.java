package com.Cms.Login.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Cms.Login.entities.Login;
import com.Cms.Login.entities.LoginChek;
import com.Cms.Login.services.LoginService;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
public class LoginController {
	
	@Autowired
	LoginService lservice;
	
	@PostMapping("/chkLogin")
	public Login chkLogin(@RequestBody LoginChek lcheck)
	{
		return lservice.getLogin(lcheck.getUsername(), lcheck.getPassword());
	}

}
