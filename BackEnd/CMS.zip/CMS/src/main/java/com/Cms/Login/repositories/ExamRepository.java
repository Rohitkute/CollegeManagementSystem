package com.Cms.Login.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Cms.Login.entities.Department;
import com.Cms.Login.entities.Exam;

public interface ExamRepository extends JpaRepository<Exam, Long> {
	List<Exam> findAllByDepartment(Department dept);

}
