package com.Cms.Login.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Cms.Login.entities.Course;

public interface CourseRepository extends JpaRepository<Course, Long> {
	Optional<Course> findByCourseName(String courseName);
	Optional<List<Course>> findAllByDepartmentDepartmentName(String deptName);

}
